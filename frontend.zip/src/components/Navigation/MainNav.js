import React from 'react';
import './Styles.css';
import './css';
import { NavLink } from 'react-router-dom';
import BannerMenu2 from './img/banner-menu2.jpg';
import BannerMenu1 from './img/banner-menu1.jpg';
import LogoMain from './img/logo4.png';

class mainNavigation extends React.Component  {

  render ()   {
  
    
      return (
        <header id="header">
  <div className="header-banner">
  </div>
    <div className="header-top hidden-md-down">
    <div className="container-fluid">
      <div className="row">
        <div className="col col col-md-2" id="_desktop_logo">
          <NavLink to='/'>
          
            <img className="logo img-responsive" src={LogoMain} alt="Ecolife  Responsive Prestashop Theme" />
            </NavLink>
        </div>
        <div className=" col col-md-10 col-sm-12 position-static">
          <div id="_desktop_megamenu" className="use-sticky ">
            <div className="pos-menu-horizontal">
              <ul className="menu-content"> 
                <li className="home menu-item menu-item22   ">
                  <NavLink to="/">
                  
                    <i className="ion-android-home" />
                    <span>Home</span>
                  
                  </NavLink>
                </li>
                <li className=" menu-item menu-item21  hasChild ">
                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/68-electronics.html">
                    <i className="ion-ios-monitor-outline" />
                    <span>PC's &amp; Laptops</span>
                    <i className="hidden-md-down ion-ios-arrow-down" />					</a>
                  <span className="icon-drop-mobile"><i className="material-icons add">add </i><i className="material-icons remove">remove </i></span>						<div className="pos-sub-menu menu-dropdown col-xs-12 col-sm-12  menu_slidedown">
                    <div className="pos-sub-inner">
                      <div className="pos-menu-row row ">
                        <div className="pos-menu-col col-xs-6 col-sm-3  ">
                          <ul className="ul-column ">
                            <li className="submenu-item ">
                              <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/69-accessories-parts.html">Accessories &amp; Parts</a>
                              <span className="icon-drop-mobile"><i className="material-icons add">add </i><i className="material-icons remove">remove </i></span>																													    <ul className="category-sub-menu">
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/75-cables-adapters.html">Cables &amp; Adapters</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/76-batteries.html">Batteries</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/77-chargers.html">Chargers</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/78-bags-cases.html">Bags &amp; Cases</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/79-electronic-cigarettes.html">Electronic Cigarettes</a>
                                </li>
                              </ul>
                            </li>
                          </ul>
                        </div>
                        <div className="pos-menu-col col-xs-6 col-sm-3  ">
                          <ul className="ul-column ">
                            <li className="submenu-item ">
                              <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/70-audio-video.html">Phones &amp; Accesories</a>
                              <span className="icon-drop-mobile"><i className="material-icons add">add </i><i className="material-icons remove">remove </i></span>																													    <ul className="category-sub-menu">
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/80-televisions.html">Televisions</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/81-tv-receivers.html">TV Receivers</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/82-projectors.html">Projectors</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/83-audio-amplifier-boards.html">Audio Amplifier Boards</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/84-tv-sticks.html">TV Sticks</a>
                                </li>
                              </ul>
                            </li>
                          </ul>
                        </div>
                        <div className="pos-menu-col col-xs-6 col-sm-3  ">
                          <ul className="ul-column ">
                            <li className="submenu-item ">
                              <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/72-portable-audio-video.html">Portable Audio &amp; Video</a>
                              <span className="icon-drop-mobile"><i className="material-icons add">add </i><i className="material-icons remove">remove </i></span>																													    <ul className="category-sub-menu">
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/90-headphones.html">Headphones</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/91-speakers.html">Speakers</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/92-mp3-players.html">MP3 Players</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/93-vrar-devices.html">VR/AR Devices</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/94-microphones.html">Microphones</a>
                                </li>
                              </ul>
                            </li>
                          </ul>
                        </div>
                        <div className="pos-menu-col col-xs-6 col-sm-3  ">
                          <ul className="ul-column ">
                            <li className="submenu-item ">
                              <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/73-smart-electronics.html">Smart Electronics</a>
                              <span className="icon-drop-mobile"><i className="material-icons add">add </i><i className="material-icons remove">remove </i></span>																													    <ul className="category-sub-menu">
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/95-wearable-devices.html">Wearable Devices</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/96-smart-home-appliances.html">Smart Home Appliances</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/97-smart-remote-controls.html">Smart Remote Controls</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/98-smart-watches.html">Smart Watches</a>
                                </li>
                                <li>
                                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/99-smart-wristbands.html">Smart Wristbands</a>
                                </li>
                              </ul>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div className="pos-menu-row row ">
                        <div className="pos-menu-col col-xs-12 col-sm-6  ">
                          <ul className="ul-column ">
                            <li className="submenu-item ">
                              <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/index.html#" className="img_desktop"><img src={BannerMenu1} alt={'banner1'} /></a>
                            </li>
                          </ul>
                        </div>
                        <div className="pos-menu-col col-xs-12 col-sm-6  ">
                          <ul className="ul-column ">
                            <li className="submenu-item ">
                              <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/index.html#" className="img_desktop"><img src={BannerMenu2} alt={'banner2'} /></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li className=" menu-item menu-item23  hasChild ">
                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/70-audio-video.html">
                    <i className="ion-ios-mic-outline" />
                    <span>  Phones &amp; Accesories</span>
                    <i className="hidden-md-down ion-ios-arrow-down" />					</a>
                  <span className="icon-drop-mobile"><i className="material-icons add">add</i><i className="material-icons remove">remove </i></span><div className="menu-dropdown cat-drop-menu menu_slidedown"><ul className="pos-sub-inner"><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/80-televisions.html" className><span>Televisions</span></a></li><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/81-tv-receivers.html" className><span>TV Receivers</span></a></li><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/82-projectors.html" className><span>Projectors</span></a></li><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/83-audio-amplifier-boards.html" className><span>Audio Amplifier Boards</span></a></li><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/84-tv-sticks.html" className><span>TV Sticks</span></a></li></ul></div>
                </li>
                <li className=" menu-item menu-item25  hasChild ">
                  <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/71-camera-photo.html">
                    <i className="ion-ios-reverse-camera-outline" />
                    <span> Drones &amp; Camera's</span>
                    <i className="hidden-md-down ion-ios-arrow-down" />					</a>
                  <span className="icon-drop-mobile"><i className="material-icons add">add</i><i className="material-icons remove">remove </i></span><div className="menu-dropdown cat-drop-menu menu_slidedown"><ul className="pos-sub-inner"><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/85-digital-cameras.html" className><span>Digital Cameras</span></a></li><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/86-camcorders.html" className><span>Camcorders</span></a></li><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/87-camera-drones.html" className><span>Camera Drones</span></a></li><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/88-action-cameras.html" className><span>Action Cameras</span></a></li><li><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/89-photo-studio-supplies.html" className><span>Photo Studio Supplies</span></a></li></ul></div>
                </li>
                <li className=" menu-item menu-item27   ">
                  
                <NavLink to="/contact">
                
                    <i className="ion-android-globe" />
                    <span><a href="/contact">Contact Us</a></span>
                    
                    </NavLink>
                </li>
              </ul>
            </div>
          </div>
          <div id="_desktop_cart_block">
            <div className="blockcart cart-preview" data-refresh-url="//demo.posthemes.com/pos_ecolife_digital/digital3/en/module/ps_shoppingcart/ajax" data-cartitems={0}>
              <div className="button_cart">
                <a rel="nofollow" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/cart75f4.html?action=show" className="desktop hidden-md-down">
                  <span className="item_count">0</span>
                  <span className="item_total">$0.00</span>
                </a>
                <a rel="nofollow" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/cart75f4.html?action=show" className="mobile hidden-lg-up">
                  <span className="item_count">0</span>
                </a>
              </div>
              <div className="popup_cart">
                <div className="content-cart">
                  <div className="mini_cart_arrow" />
                  <ul>
                  </ul>
                  <div className="price_content">
                    <div className="cart-subtotals">
                      <div className="products price_inline">
                        <span className="label">Subtotal</span>
                        <span className="value">0.00</span>
                      </div>
                      <div className=" price_inline">
                        <span className="label" />
                        <span className="value" />
                      </div>
                      <div className="shipping price_inline">
                        <span className="label">Shipping</span>
                        <span className="value">Free</span>
                      </div>
                      <div className="tax price_inline">
                        <span className="label">Taxes</span>
                        <span className="value">$0.00</span>
                      </div>
                    </div>
                    <div className="cart-total price_inline">
                      <span className="label">Total</span>
                      <span className="value">$0.00</span>
                    </div>
                  </div>
                  <div className="checkout">
                    <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/cart75f4.html?action=show" className="btn btn-primary">Checkout</a> 
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div id="_desktop_wishtlist">
            <div className="wishtlist_top">
              <a className href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/logindf17.html">
                <i className="ion-android-favorite-outline" />
                <span className="txt_wishlist">Wishlist</span>
                (<span className="cart-wishlist-number">0</span>)
              </a>
            </div>
          </div><div id="_desktop_compare">
            <div className="compare_top">
              <a href="http://demo.posthemes.com/pos_ecolife_digital/digital3/module/poscompare/comparePage">
                <i className="ion-ios-shuffle-strong" /> <span>Compare (<span id="poscompare-nb">0</span>)</span>
              </a>
            </div>
          </div>
          <div id="_desktop_contact_link">
            <div className="contact-link">
              <div className="phone">
                <p>Call us:</p>
                <a href="tel:(+800)345678">(+800)345678</a>
              </div>
            </div>
          </div>
          {/* pos search module TOP */}
          <div id="_desktop_search_category"> 
            <div className="dropdown js-dropdown">
              <span className="search-icon" data-toggle="dropdown"><i className="ion-ios-search-strong" /></span> 
              <div id="pos_search_top" className="dropdown-menu">
                <form method="get" action="http://demo.posthemes.com/pos_ecolife_digital/digital3/en/search" id="searchbox" className="form-inline form_search show-categories" data-search-controller-url="/pos_ecolife_digital/digital3/modules/possearchproducts/SearchProducts.php">
                  <label htmlFor="pos_query_top">{/* image on background */}</label>
                  <input type="hidden" name="controller" defaultValue="search" />  
                  <div className="pos_search form-group">
                    <select className="bootstrap-select" name="poscats">
                      <option value={0}>All categories</option>
                      <option value={68}>
                        Electronics
                      </option>
                      <option value={69}>
                        - -  Accessories &amp; Parts
                      </option>
                      <option value={75}>
                        - - - -  Cables &amp; Adapters
                      </option>
                      <option value={76}>
                        - - - -  Batteries
                      </option>
                      <option value={77}>
                        - - - -  Chargers
                      </option>
                      <option value={78}>
                        - - - -  Bags &amp; Cases
                      </option>
                      <option value={79}>
                        - - - -  Electronic Cigarettes
                      </option>
                      <option value={70}>
                        - -  Audio &amp; Video
                      </option>
                      <option value={80}>
                        - - - -  Televisions
                      </option>
                      <option value={81}>
                        - - - -  TV Receivers
                      </option>
                      <option value={82}>
                        - - - -  Projectors
                      </option>
                      <option value={83}>
                        - - - -  Audio Amplifier Boards
                      </option>
                      <option value={84}>
                        - - - -  TV Sticks
                      </option>
                      <option value={71}>
                        - -  Camera &amp; Photo
                      </option>
                      <option value={85}>
                        - - - -  Digital Cameras
                      </option>
                      <option value={86}>
                        - - - -  Camcorders
                      </option>
                      <option value={87}>
                        - - - -  Camera Drones
                      </option>
                      <option value={88}>
                        - - - -  Action Cameras
                      </option>
                      <option value={89}>
                        - - - -  Photo Studio Supplies
                      </option>
                      <option value={72}>
                        - -  Portable Audio &amp; Video
                      </option>
                      <option value={90}>
                        - - - -  Headphones
                      </option>
                      <option value={91}>
                        - - - -  Speakers
                      </option>
                      <option value={92}>
                        - - - -  MP3 Players
                      </option>
                      <option value={93}>
                        - - - -  VR/AR Devices
                      </option>
                      <option value={94}>
                        - - - -  Microphones
                      </option>
                      <option value={73}>
                        - -  Smart Electronics
                      </option>
                      <option value={95}>
                        - - - -  Wearable Devices
                      </option>
                      <option value={96}>
                        - - - -  Smart Home Appliances
                      </option>
                      <option value={97}>
                        - - - -  Smart Remote Controls
                      </option>
                      <option value={98}>
                        - - - -  Smart Watches
                      </option>
                      <option value={99}>
                        - - - -  Smart Wristbands
                      </option>
                      <option value={74}>
                        - -  Video Games
                      </option>
                      <option value={100}>
                        - - - -  Handheld Game Players
                      </option>
                      <option value={101}>
                        - - - -  Game Controllers
                      </option>
                      <option value={102}>
                        - - - -  Joysticks
                      </option>
                      <option value={103}>
                        - - - -  Stickers
                      </option>
                    </select>
                  </div>
                  <span role="status" aria-live="polite" className="ui-helper-hidden-accessible" /><input type="text" name="s" defaultValue placeholder="Enter your search key ... " id="pos_query_top" className="search_query form-control ac_input ui-autocomplete-input" autoComplete="off" />
                  <button type="submit" className="btn btn-default search_submit">
                    <i className="ion-ios-search-strong" />
                  </button>
                </form>
              </div>
            </div>
          </div>
          {/* /pos search module TOP */}
        </div>
      </div>
    </div>
  </div>
</header>

      

      );
      }

    }

export default mainNavigation;
