import React from 'react';
import '../Navigation/Styles.css';
import '../Navigation/css';
// import { NavLink } from 'react-router-dom';
import GooglePlay from './img/google_play.png';
import AppStore from './img/app_store.png';
import LogoFooter from './img/logo4.png';
import Payment from './img/payment.png';

class Footer extends React.Component  {

  render ()   {
  
    
      return (
        <div>
  <footer id="footer">
    <div className="footer-container">
      <div className="footer_top">
        <div className="container">
          <div className="row">
            <div className="col-md-4 links footer_block">
              <div className="footer_about_us">
                <div className="logo_footer"><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/index.html#"><img src={LogoFooter} alt={'logo_footer'} /></a></div>
                <div className="desc_info">
                  <p className="txt_info">We are a team of designers and developers that create high quality Magento, Prestashop, Opencart.</p>
                  <div className="need_help">
                    <p>NEED HELP?</p>
                    <p className="phone">(+254) 719 616 550, (+254) 728 428 342</p>
                  </div>
                </div>
              </div>
              <div className="col-footer social_follow "> 
                <ul>
                  <li className="facebook"><a href="https://www.facebook.com/posthemes" target="blank">Facebook</a></li>
                  <li className="twitter"><a href="https://twitter.com/posthemes" target="blank">Twitter</a></li>
                  <li className="youtube"><a href="https://www.youtube.com/user/posthemes" target="blank">YouTube</a></li>
                  <li className="googleplus"><a href="https://plus.google.com/100616268634541521861/posts" target="blank">Google +</a></li>
                  <li className="instagram"><a href="https://www.instagram.com/posthemes9234" target="blank">Instagram</a></li>
                </ul>
              </div>
            </div>
            <div className="col-md-2 links footer_block">
              <h3 className=" hidden-sm-down">Information</h3>
              <div className="title clearfix hidden-md-up" data-target="#footer_2" data-toggle="collapse">
                <h3>Information</h3>
                <span className="float-xs-right">
                  <span className="navbar-toggler collapse-icons">
                    <i className="material-icons add">keyboard_arrow_down</i>
                    <i className="material-icons remove">keyboard_arrow_up</i>
                  </span>
                </span>
              </div>
              <ul id="footer_2" className="collapse footer_list">
                <li>
                  <a id="link-cms-page-1-2" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/content/1-delivery.html" title="Our terms and conditions of delivery">
                    Delivery
                  </a>
                </li>
                <li>
                  <a id="link-cms-page-4-2" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/content/4-about-us.html" title="Learn more about us">
                    About us
                  </a>
                </li>
                <li>
                  <a id="link-cms-page-5-2" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/content/5-secure-payment.html" title="Our secure payment method">
                    Secure payment
                  </a>
                </li>
                <li>
                  <a id="link-static-page-contact-2" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/contact-us.html" title="Use our form to contact us">
                    Contact us
                  </a>
                </li>
                <li>
                  <a id="link-static-page-sitemap-2" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/sitemap.html" title="Lost ? Find what your are looking for">
                    Sitemap
                  </a>
                </li>
                <li>
                  <a id="link-static-page-stores-2" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/stores.html" title>
                    Stores
                  </a>
                </li>
              </ul>
            </div>
            <div className="col-md-2 links footer_block">
              <h3 className=" hidden-sm-down">Custom Links</h3>
              <div className="title clearfix hidden-md-up" data-target="#footer_3" data-toggle="collapse">
                <h3>Custom Links</h3>
                <span className="float-xs-right">
                  <span className="navbar-toggler collapse-icons">
                    <i className="material-icons add">keyboard_arrow_down</i>
                    <i className="material-icons remove">keyboard_arrow_up</i>
                  </span>
                </span>
              </div>
              <ul id="footer_3" className="collapse footer_list">
                <li>
                  <a id="link-cms-page-2-3" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/content/2-legal-notice.html" title="Legal notice">
                    Legal Notice
                  </a>
                </li>
                <li>
                  <a id="link-product-page-prices-drop-3" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/prices-drop.html" title="Our special products">
                    Prices drop
                  </a>
                </li>
                <li>
                  <a id="link-product-page-new-products-3" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/new-products.html" title="Our new products">
                    New products
                  </a>
                </li>
                <li>
                  <a id="link-product-page-best-sales-3" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/best-sales.html" title="Our best sales">
                    Best sales
                  </a>
                </li>
                <li>
                  <a id="link-static-page-authentication-3" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/login.html" title>
                    Login
                  </a>
                </li>
                <li>
                  <a id="link-static-page-my-account-3" className="cms-page-link" href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/loginfd9a.html" title>
                    My account
                  </a>
                </li>
              </ul>
            </div>
            <div className="col-md-4 links footer_block">
              <h3 className=" hidden-sm-down">Newsletter</h3>
              <div className="title clearfix hidden-md-up" data-target="#footer_4" data-toggle="collapse">
                <h3>Newsletter</h3>
                <span className="float-xs-right">
                  <span className="navbar-toggler collapse-icons">
                    <i className="material-icons add">keyboard_arrow_down</i>
                    <i className="material-icons remove">keyboard_arrow_up</i>
                  </span>
                </span>
              </div>
              <div id="footer_4" className="collapse footer_list">
                <div className="img_app"><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/index.html#"><img src={AppStore} alt={'app_store'} /></a> <a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/index.html#"><img src={GooglePlay} alt={'google_play'} /></a></div>
                <div className="ft_newsletter col-footer"> 
                  <p>You may unsubscribe at any moment. For that purpose, please find our contact info in the legal notice.</p>
                  <div className="col col_form">
                    <form action="http://demo.posthemes.com/pos_ecolife_digital/digital3/en/#footer" method="post">
                      <input className="btn btn-primary" name="submitNewsletter" type="submit" defaultValue="Sign up" />
                      <div className="input-wrapper">
                        <input name="email" type="email" defaultValue placeholder="Your email address" />
                      </div>
                      <input type="hidden" name="action" defaultValue={0} />
                      <div className="clearfix" />
                    </form>
                  </div>
                </div>
              </div>	
            </div>
          </div>
        </div>
      </div>
      <div className="footer_bottom">
        <div className="container">
          <div className="row">
            <div className="col-md-4 links footer_block">
              <div className="copyright">Copyright © <a href="http://posthemes.com/">Noola 2020</a>. All Rights Reserved</div>
            </div>
            <div className="col-md-8 links footer_block">
              <div className="payment"><img src={Payment} alt={'payment'} /></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <div className="back-top" style={{display: 'none'}}><a href="file:///D:/E-Commerce/Frontend/Noola/demo.posthemes.com/pos_ecolife_digital/digital3/en/index.html#" className="back-top-button"> </a></div>
  <div id="poscompare-notification" className>
    <div className="notification-inner">
      <span className="notification-title"><i className="fa fa-check" aria-hidden="true" />  Product added to compare.</span>
    </div>
  </div>
  {/* Mirrored from demo.posthemes.com/pos_ecolife_digital/digital3/en/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Jun 2020 14:42:29 GMT */}
  <ul className="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all" id="ui-id-1" tabIndex={0} style={{display: 'none'}} />
</div>


      

      );
      }

    }

export default Footer;
